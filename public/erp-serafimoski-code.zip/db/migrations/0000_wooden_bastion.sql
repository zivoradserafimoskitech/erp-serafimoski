CREATE TABLE `audit_log` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`userId` bigint unsigned,
	`user_name` varchar(255),
	`action` varchar(50) NOT NULL,
	`entity_type` varchar(50) NOT NULL,
	`entity_id` bigint unsigned,
	`old_value` text,
	`new_value` text,
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `audit_log_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `company_settings` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`address` text,
	`edb` varchar(20) NOT NULL,
	`embs` varchar(20),
	`bank_name` varchar(255),
	`bank_account` varchar(50),
	`phone` varchar(50),
	`email` varchar(320),
	`logo_url` text,
	`default_vat_rate` decimal(5,2) NOT NULL DEFAULT '18',
	`valuation_method` enum('weighted_average','fifo') NOT NULL DEFAULT 'weighted_average',
	`currency` varchar(10) NOT NULL DEFAULT 'MKD',
	`timezone` varchar(50) NOT NULL DEFAULT 'Europe/Skopje',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `company_settings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `customers` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`company` varchar(255),
	`contactPerson` varchar(255),
	`email` varchar(320),
	`phone` varchar(50),
	`address` text,
	`city` varchar(100),
	`country` varchar(100) DEFAULT 'Македонија',
	`taxNumber` varchar(50),
	`edb` varchar(20),
	`notes` text,
	`isActive` enum('active','inactive') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `customers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `delivery_notes` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`dnNumber` varchar(50) NOT NULL,
	`customerId` bigint unsigned NOT NULL,
	`orderId` bigint unsigned,
	`status` enum('draft','issued','delivered','cancelled') NOT NULL DEFAULT 'draft',
	`issueDate` date NOT NULL,
	`deliveryDate` date,
	`totalItems` int NOT NULL DEFAULT 0,
	`notes` text,
	`createdBy` bigint unsigned,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `delivery_notes_id` PRIMARY KEY(`id`),
	CONSTRAINT `delivery_notes_dnNumber_unique` UNIQUE(`dnNumber`)
);
--> statement-breakpoint
CREATE TABLE `doc_counters` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`kind` varchar(10) NOT NULL,
	`year` int NOT NULL,
	`value` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `doc_counters_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `document_items` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`documentId` bigint unsigned NOT NULL,
	`documentType` enum('invoice','incoming_invoice','receipt','delivery_note') NOT NULL,
	`description` varchar(500) NOT NULL,
	`quantity` decimal(12,3) NOT NULL DEFAULT '1',
	`unit` varchar(20) NOT NULL DEFAULT 'ком',
	`unitPrice` decimal(12,2) NOT NULL,
	`discount` decimal(5,2) NOT NULL DEFAULT '0',
	`totalPrice` decimal(12,2) NOT NULL,
	`vatRate` decimal(5,2) NOT NULL DEFAULT '18',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `document_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `e_invoices` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`invoiceId` bigint unsigned NOT NULL,
	`ujpInvoiceId` varchar(255),
	`status` enum('pending','sent_to_ujp','approved','rejected','cancelled') NOT NULL DEFAULT 'pending',
	`xmlContent` text,
	`responseMessage` text,
	`sentAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `e_invoices_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `incoming_invoices` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`supplierInvoiceNumber` varchar(50) NOT NULL,
	`supplierId` bigint unsigned NOT NULL,
	`poId` bigint unsigned,
	`receipt_id` bigint unsigned,
	`status` enum('received','verified','paid','disputed','cancelled') NOT NULL DEFAULT 'received',
	`issueDate` date,
	`receivedDate` date NOT NULL,
	`dueDate` date,
	`subtotal` decimal(14,2) NOT NULL DEFAULT '0',
	`vatRate` decimal(5,2) NOT NULL DEFAULT '18',
	`vatAmount` decimal(14,2) NOT NULL DEFAULT '0',
	`totalAmount` decimal(14,2) NOT NULL DEFAULT '0',
	`currency` varchar(10) NOT NULL DEFAULT 'MKD',
	`notes` text,
	`fileUrl` text,
	`createdBy` bigint unsigned,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `incoming_invoices_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `inventory_count_items` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`count_id` bigint unsigned NOT NULL,
	`materialId` bigint unsigned NOT NULL,
	`system_qty` decimal(12,3) NOT NULL,
	`counted_qty` decimal(12,3),
	`difference` decimal(12,3),
	`unit_cost` decimal(12,2),
	`total_difference` decimal(12,2),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `inventory_count_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `inventory_counts` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`count_number` varchar(50) NOT NULL,
	`warehouseId` bigint unsigned NOT NULL,
	`status` enum('draft','in_progress','completed','cancelled') NOT NULL DEFAULT 'draft',
	`count_date` date NOT NULL,
	`notes` text,
	`createdBy` bigint unsigned,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `inventory_counts_id` PRIMARY KEY(`id`),
	CONSTRAINT `inventory_counts_count_number_unique` UNIQUE(`count_number`)
);
--> statement-breakpoint
CREATE TABLE `inventory_transactions` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`materialId` bigint unsigned NOT NULL,
	`warehouseId` bigint unsigned NOT NULL,
	`type` enum('receipt','issue','adjustment','return','scrap','transfer_in','transfer_out') NOT NULL,
	`quantity` decimal(12,3) NOT NULL,
	`unitCost` decimal(12,2),
	`totalCost` decimal(12,2),
	`reference` varchar(255),
	`source_doc_type` varchar(50),
	`source_doc_id` bigint unsigned,
	`notes` text,
	`createdBy` bigint unsigned,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `inventory_transactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `invoices` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`invoiceNumber` varchar(50) NOT NULL,
	`customerId` bigint unsigned NOT NULL,
	`orderId` bigint unsigned,
	`work_order_id` bigint unsigned,
	`status` enum('draft','issued','sent','paid','overdue','cancelled') NOT NULL DEFAULT 'draft',
	`invoiceType` enum('standard','proforma','credit_note') NOT NULL DEFAULT 'standard',
	`issueDate` date NOT NULL,
	`dueDate` date,
	`subtotal` decimal(14,2) NOT NULL DEFAULT '0',
	`vatRate` decimal(5,2) NOT NULL DEFAULT '18',
	`vatAmount` decimal(14,2) NOT NULL DEFAULT '0',
	`totalAmount` decimal(14,2) NOT NULL DEFAULT '0',
	`currency` varchar(10) NOT NULL DEFAULT 'MKD',
	`notes` text,
	`eInvoiceId` varchar(255),
	`original_invoice_id` bigint unsigned,
	`createdBy` bigint unsigned,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `invoices_id` PRIMARY KEY(`id`),
	CONSTRAINT `invoices_invoiceNumber_unique` UNIQUE(`invoiceNumber`)
);
--> statement-breakpoint
CREATE TABLE `labor_rates` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`role` varchar(255) NOT NULL,
	`role_code` varchar(50) NOT NULL,
	`cost_per_hour` decimal(12,2) NOT NULL,
	`gross_salary` decimal(12,2) NOT NULL DEFAULT '0',
	`contributions_pct` decimal(5,2) NOT NULL DEFAULT '32',
	`description` text,
	`isActive` enum('active','inactive') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `labor_rates_id` PRIMARY KEY(`id`),
	CONSTRAINT `labor_rates_role_code_unique` UNIQUE(`role_code`)
);
--> statement-breakpoint
CREATE TABLE `machines` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`code` varchar(50) NOT NULL,
	`type` enum('laser','plasma','bending','welding','painting','grinding','drilling','cnc','other') NOT NULL,
	`cost_per_hour` decimal(12,2) NOT NULL DEFAULT '0',
	`cost_per_meter` decimal(12,2) NOT NULL DEFAULT '0',
	`annual_amortization` decimal(14,2) NOT NULL DEFAULT '0',
	`annual_electricity` decimal(14,2) NOT NULL DEFAULT '0',
	`annual_gas` decimal(14,2) NOT NULL DEFAULT '0',
	`annual_service` decimal(14,2) NOT NULL DEFAULT '0',
	`annual_hours` decimal(8,2) NOT NULL DEFAULT '2000',
	`isActive` enum('active','inactive') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `machines_id` PRIMARY KEY(`id`),
	CONSTRAINT `machines_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `material_lots` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`materialId` bigint unsigned NOT NULL,
	`warehouseId` bigint unsigned NOT NULL,
	`receiptId` bigint unsigned,
	`quantity` decimal(12,3) NOT NULL,
	`remaining_qty` decimal(12,3) NOT NULL,
	`unit_cost` decimal(12,2) NOT NULL,
	`landed_cost` decimal(12,2) NOT NULL DEFAULT '0',
	`date` date NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `material_lots_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `material_stock` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`materialId` bigint unsigned NOT NULL,
	`warehouseId` bigint unsigned NOT NULL,
	`quantity` decimal(12,3) NOT NULL DEFAULT '0',
	`avgCost` decimal(12,2) NOT NULL DEFAULT '0',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `material_stock_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `materials` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`code` varchar(100) NOT NULL,
	`type` enum('steel_sheet','steel_profile','steel_bar','aluminum_sheet','aluminum_profile','stainless_sheet','pipe','angle','channel','screws','welding','paint','other') NOT NULL,
	`unit` enum('kg','m','m2','pcs','l','sheet','hour','m_cut','bend') NOT NULL,
	`description` text,
	`minStock` decimal(12,3) NOT NULL DEFAULT '0',
	`currentStock` decimal(12,3) NOT NULL DEFAULT '0',
	`avgCost` decimal(12,2) NOT NULL DEFAULT '0',
	`lastPurchasePrice` decimal(12,2) NOT NULL DEFAULT '0',
	`location` varchar(100),
	`isActive` enum('active','inactive') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `materials_id` PRIMARY KEY(`id`),
	CONSTRAINT `materials_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `order_items` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`orderId` bigint unsigned NOT NULL,
	`description` varchar(500) NOT NULL,
	`drawingNumber` varchar(100),
	`quantity` int NOT NULL,
	`unitPrice` decimal(12,2) NOT NULL,
	`totalPrice` decimal(12,2) NOT NULL,
	`cost_price` decimal(12,2) NOT NULL DEFAULT '0',
	`margin_amount` decimal(12,2) NOT NULL DEFAULT '0',
	`material` varchar(255),
	`dimensions` varchar(255),
	`product_id` bigint unsigned,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `order_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`orderNumber` varchar(50) NOT NULL,
	`customerId` bigint unsigned NOT NULL,
	`quoteId` bigint unsigned,
	`status` enum('pending','confirmed','in_production','ready','delivered','cancelled') NOT NULL DEFAULT 'pending',
	`priority` enum('low','normal','high','urgent') NOT NULL DEFAULT 'normal',
	`totalAmount` decimal(14,2) NOT NULL DEFAULT '0',
	`cost_amount` decimal(14,2) NOT NULL DEFAULT '0',
	`margin_amount` decimal(14,2) NOT NULL DEFAULT '0',
	`margin_percent` decimal(5,2) NOT NULL DEFAULT '0',
	`deliveryDate` date,
	`notes` text,
	`createdBy` bigint unsigned,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `orders_id` PRIMARY KEY(`id`),
	CONSTRAINT `orders_orderNumber_unique` UNIQUE(`orderNumber`)
);
--> statement-breakpoint
CREATE TABLE `overhead` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`rate_type` enum('pct_of_labor','per_hour','per_m2','fixed') NOT NULL,
	`rate_value` decimal(12,4) NOT NULL,
	`annual_amount` decimal(14,2) NOT NULL DEFAULT '0',
	`description` text,
	`isActive` enum('active','inactive') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `overhead_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `parsed_invoices` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`originalFileName` varchar(500) NOT NULL,
	`supplierName` varchar(255),
	`invoiceNumber` varchar(100),
	`issueDate` date,
	`dueDate` date,
	`totalAmount` decimal(14,2),
	`vatAmount` decimal(14,2),
	`currency` varchar(10),
	`rawText` text,
	`fileUrl` text,
	`document_type` enum('invoice','receipt','delivery_note','other') NOT NULL DEFAULT 'invoice',
	`status` enum('parsed','verified','imported') NOT NULL DEFAULT 'parsed',
	`matchedInvoiceId` bigint unsigned,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `parsed_invoices_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `parsed_receipt_items` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`parsed_invoice_id` bigint unsigned NOT NULL,
	`raw_description` text NOT NULL,
	`matched_material_id` bigint unsigned,
	`matched_material_name` varchar(255),
	`match_confidence` decimal(5,2) NOT NULL DEFAULT '0',
	`quantity` decimal(12,3),
	`unit` varchar(20),
	`unit_price` decimal(12,2),
	`total_price` decimal(12,2),
	`vat_rate` decimal(5,2) DEFAULT '18',
	`is_confirmed` enum('pending','confirmed','rejected') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `parsed_receipt_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `product_components` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`product_id` bigint unsigned NOT NULL,
	`kind` enum('material','service') NOT NULL,
	`ref_id` bigint unsigned NOT NULL,
	`per_unit` decimal(12,6) NOT NULL,
	`waste_pct` decimal(5,2) NOT NULL DEFAULT '0',
	`scale` enum('area','perimeter','length','fixed') NOT NULL DEFAULT 'area',
	`notes` text,
	`sort_order` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `product_components_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `products` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`code` varchar(100) NOT NULL,
	`category` enum('laser_fence','decorative_fence','metal_fence','balcony_railing','stair_railing','gate','pergola','canopy','metal_door','industrial_product','custom_metalwork','shelf','worktable','other') NOT NULL,
	`description` text,
	`unit` enum('m2','m','kg','pcs','set') NOT NULL,
	`basis` enum('m2','m','pcs') NOT NULL DEFAULT 'm2',
	`defaultPrice` decimal(12,2) NOT NULL DEFAULT '0',
	`materialCost` decimal(12,2) NOT NULL DEFAULT '0',
	`laborCost` decimal(12,2) NOT NULL DEFAULT '0',
	`machine_cost` decimal(12,2) NOT NULL DEFAULT '0',
	`overhead_cost` decimal(12,2) NOT NULL DEFAULT '0',
	`total_cost` decimal(12,2) NOT NULL DEFAULT '0',
	`isActive` enum('active','inactive') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `products_id` PRIMARY KEY(`id`),
	CONSTRAINT `products_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `purchase_order_items` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`purchaseOrderId` bigint unsigned NOT NULL,
	`materialId` bigint unsigned NOT NULL,
	`description` varchar(500) NOT NULL,
	`quantity` decimal(12,3) NOT NULL,
	`unitPrice` decimal(12,2) NOT NULL,
	`totalPrice` decimal(12,2) NOT NULL,
	`receivedQuantity` decimal(12,3) NOT NULL DEFAULT '0',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `purchase_order_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `purchase_orders` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`poNumber` varchar(50) NOT NULL,
	`supplierId` bigint unsigned NOT NULL,
	`status` enum('draft','sent','confirmed','partial','received','cancelled') NOT NULL DEFAULT 'draft',
	`totalAmount` decimal(14,2) NOT NULL DEFAULT '0',
	`expectedDate` date,
	`notes` text,
	`createdBy` bigint unsigned,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `purchase_orders_id` PRIMARY KEY(`id`),
	CONSTRAINT `purchase_orders_poNumber_unique` UNIQUE(`poNumber`)
);
--> statement-breakpoint
CREATE TABLE `quotation_items` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`quotationId` bigint unsigned NOT NULL,
	`itemType` enum('material','service','product') NOT NULL,
	`referenceId` bigint unsigned,
	`description` varchar(500) NOT NULL,
	`quantity` decimal(12,3) NOT NULL,
	`unit` varchar(20) NOT NULL,
	`unitPrice` decimal(12,2) NOT NULL,
	`unit_cost` decimal(12,2) NOT NULL DEFAULT '0',
	`totalPrice` decimal(12,2) NOT NULL,
	`total_cost` decimal(12,2) NOT NULL DEFAULT '0',
	`vatRate` decimal(5,2) NOT NULL DEFAULT '18',
	`notes` text,
	`sortOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `quotation_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `quotations` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`quoteNumber` varchar(50) NOT NULL,
	`customerId` bigint unsigned NOT NULL,
	`status` enum('draft','sent','accepted','rejected','expired','converted') NOT NULL DEFAULT 'draft',
	`subtotal` decimal(14,2) NOT NULL DEFAULT '0',
	`cost_amount` decimal(14,2) NOT NULL DEFAULT '0',
	`margin_amount` decimal(14,2) NOT NULL DEFAULT '0',
	`margin_percent` decimal(5,2) NOT NULL DEFAULT '0',
	`vatRate` decimal(5,2) NOT NULL DEFAULT '18',
	`vatAmount` decimal(14,2) NOT NULL DEFAULT '0',
	`totalAmount` decimal(14,2) NOT NULL DEFAULT '0',
	`currency` varchar(10) NOT NULL DEFAULT 'MKD',
	`validUntil` date,
	`deliveryDays` int DEFAULT 14,
	`paymentTerms` varchar(255) DEFAULT '14 дена',
	`notes` text,
	`convertedOrderId` bigint unsigned,
	`createdBy` bigint unsigned,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `quotations_id` PRIMARY KEY(`id`),
	CONSTRAINT `quotations_quoteNumber_unique` UNIQUE(`quoteNumber`)
);
--> statement-breakpoint
CREATE TABLE `receipt_items` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`receipt_id` bigint unsigned NOT NULL,
	`materialId` bigint unsigned NOT NULL,
	`quantity` decimal(12,3) NOT NULL,
	`unit` varchar(20) NOT NULL,
	`unit_price` decimal(12,2) NOT NULL,
	`total_price` decimal(12,2) NOT NULL,
	`landed_cost_alloc` decimal(12,2) NOT NULL DEFAULT '0',
	`vat_rate` decimal(5,2) NOT NULL DEFAULT '18',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `receipt_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `receipts` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`receiptNumber` varchar(50) NOT NULL,
	`supplierId` bigint unsigned,
	`poId` bigint unsigned,
	`warehouse_id` bigint unsigned NOT NULL,
	`status` enum('draft','confirmed','cancelled') NOT NULL DEFAULT 'draft',
	`receiptDate` date NOT NULL,
	`supplier_doc_number` varchar(100),
	`transport_cost` decimal(12,2) NOT NULL DEFAULT '0',
	`customs_cost` decimal(12,2) NOT NULL DEFAULT '0',
	`other_cost` decimal(12,2) NOT NULL DEFAULT '0',
	`totalAmount` decimal(14,2) NOT NULL DEFAULT '0',
	`notes` text,
	`file_url` text,
	`createdBy` bigint unsigned,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `receipts_id` PRIMARY KEY(`id`),
	CONSTRAINT `receipts_receiptNumber_unique` UNIQUE(`receiptNumber`)
);
--> statement-breakpoint
CREATE TABLE `services` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`code` varchar(100) NOT NULL,
	`type` enum('laser_cutting','plasma_cutting','bending','mig_welding','tig_welding','grinding','drilling','electrostatic_paint','wet_paint','galvanizing','cnc_machining','labor','design','transport','installation','other') NOT NULL,
	`unit` enum('m2','m','kg','hour','pcs','job','m_cut','bend') NOT NULL,
	`description` text,
	`cost_rate` decimal(12,2) NOT NULL DEFAULT '0',
	`sale_rate` decimal(12,2) NOT NULL DEFAULT '0',
	`machine_id` bigint unsigned,
	`isActive` enum('active','inactive') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `services_id` PRIMARY KEY(`id`),
	CONSTRAINT `services_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `stock_transfer_items` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`transfer_id` bigint unsigned NOT NULL,
	`materialId` bigint unsigned NOT NULL,
	`quantity` decimal(12,3) NOT NULL,
	`unit_cost` decimal(12,2),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `stock_transfer_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `stock_transfers` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`transfer_number` varchar(50) NOT NULL,
	`from_warehouse_id` bigint unsigned NOT NULL,
	`to_warehouse_id` bigint unsigned NOT NULL,
	`status` enum('draft','confirmed','cancelled') NOT NULL DEFAULT 'draft',
	`transfer_date` date NOT NULL,
	`notes` text,
	`createdBy` bigint unsigned,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `stock_transfers_id` PRIMARY KEY(`id`),
	CONSTRAINT `stock_transfers_transfer_number_unique` UNIQUE(`transfer_number`)
);
--> statement-breakpoint
CREATE TABLE `suppliers` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`edb` varchar(20),
	`contactPerson` varchar(255),
	`email` varchar(320),
	`phone` varchar(50),
	`address` text,
	`city` varchar(100),
	`country` varchar(100) DEFAULT 'Македонија',
	`payment_terms` varchar(100) DEFAULT '30 дена',
	`default_currency` varchar(10) DEFAULT 'MKD',
	`materials` text,
	`isActive` enum('active','inactive') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `suppliers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `unit_conversions` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`from_unit_id` bigint unsigned NOT NULL,
	`to_unit_id` bigint unsigned NOT NULL,
	`factor` decimal(18,8) NOT NULL,
	`material_type` varchar(50),
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `unit_conversions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `units` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`code` varchar(20) NOT NULL,
	`name` varchar(100) NOT NULL,
	`name_mk` varchar(100),
	`category` enum('weight','length','area','volume','piece','time','other') NOT NULL DEFAULT 'other',
	`isActive` enum('active','inactive') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `units_id` PRIMARY KEY(`id`),
	CONSTRAINT `units_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`unionId` varchar(255) NOT NULL,
	`name` varchar(255),
	`email` varchar(320),
	`avatar` text,
	`role` enum('admin','office','production','warehouse') NOT NULL DEFAULT 'office',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()),
	`lastSignInAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_unionId_unique` UNIQUE(`unionId`)
);
--> statement-breakpoint
CREATE TABLE `warehouses` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`code` varchar(20) NOT NULL,
	`name` varchar(255) NOT NULL,
	`type` enum('raw_materials','finished_goods','construction_site','other') NOT NULL,
	`address` text,
	`isActive` enum('active','inactive') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `warehouses_id` PRIMARY KEY(`id`),
	CONSTRAINT `warehouses_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `work_order_materials` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`workOrderId` bigint unsigned NOT NULL,
	`materialId` bigint unsigned NOT NULL,
	`quantity` decimal(12,3) NOT NULL,
	`unit_cost` decimal(12,2) NOT NULL DEFAULT '0',
	`total_cost` decimal(12,2) NOT NULL DEFAULT '0',
	`is_actual` enum('planned','actual') NOT NULL DEFAULT 'planned',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `work_order_materials_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `work_order_operations` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`workOrderId` bigint unsigned NOT NULL,
	`operation` enum('cutting_laser','cutting_plasma','bending','welding_mig','welding_tig','grinding','drilling','painting','assembly','quality_control','packaging') NOT NULL,
	`sequence` int NOT NULL,
	`description` varchar(500),
	`estimatedTime` decimal(8,2),
	`actualTime` decimal(8,2),
	`estimated_qty` decimal(12,3),
	`actual_qty` decimal(12,3),
	`qty_unit` varchar(20),
	`status` enum('pending','in_progress','completed','skipped') NOT NULL DEFAULT 'pending',
	`operator` varchar(255),
	`cost_rate` decimal(12,2) NOT NULL DEFAULT '0',
	`cost_amount` decimal(12,2) NOT NULL DEFAULT '0',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `work_order_operations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `work_orders` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`woNumber` varchar(50) NOT NULL,
	`orderId` bigint unsigned,
	`description` varchar(500) NOT NULL,
	`status` enum('pending','in_progress','on_hold','completed','cancelled') NOT NULL DEFAULT 'pending',
	`priority` enum('low','normal','high','urgent') NOT NULL DEFAULT 'normal',
	`plannedStart` date,
	`plannedEnd` date,
	`actualStart` date,
	`actualEnd` date,
	`assignedTo` varchar(255),
	`cost_amount` decimal(14,2) NOT NULL DEFAULT '0',
	`notes` text,
	`createdBy` bigint unsigned,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `work_orders_id` PRIMARY KEY(`id`),
	CONSTRAINT `work_orders_woNumber_unique` UNIQUE(`woNumber`)
);
