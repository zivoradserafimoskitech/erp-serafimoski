-- Add OCR support tables and columns

-- Add new columns to parsed_invoices if they don't exist
ALTER TABLE `parsed_invoices` ADD COLUMN IF NOT EXISTS `document_type` enum('invoice','receipt','delivery_note','other') NOT NULL DEFAULT 'invoice';
ALTER TABLE `parsed_invoices` ADD COLUMN IF NOT EXISTS `fileUrl` text;

-- Create parsed_receipt_items table
CREATE TABLE IF NOT EXISTS `parsed_receipt_items` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`parsed_invoice_id` bigint unsigned NOT NULL,
	`raw_description` text NOT NULL,
	`matched_material_id` bigint unsigned,
	`matched_material_name` varchar(255),
	`match_confidence` decimal(5,2) NOT NULL DEFAULT '0',
	`quantity` decimal(12,3),
	`unit` varchar(20),
	`unit_price` decimal(12,2),
	`total_price` decimal(12,2),
	`vat_rate` decimal(5,2) DEFAULT '18',
	`is_confirmed` enum('pending','confirmed','rejected') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `parsed_receipt_items_id` PRIMARY KEY(`id`)
);
